export { default as DefaultLayout } from './DefaultLayout';
export { default as OnlyHeader } from './OnlyHeader';
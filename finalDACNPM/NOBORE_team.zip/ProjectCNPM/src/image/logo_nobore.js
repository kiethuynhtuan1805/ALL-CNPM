const Logo_Nobore = {
    image: require('./logo_nobore.png'),
};
export default Logo_Nobore;

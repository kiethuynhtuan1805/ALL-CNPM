const Giohang = {
    image: require('./giohang.png'),
};
export default Giohang;
const Logo = {
    image: require('./Logo.png'),
};
export default Logo;
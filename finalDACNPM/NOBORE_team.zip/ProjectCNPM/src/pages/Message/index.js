import './message.scss'
function Message() {
    return <div>
        <h2> Design message box</h2>
    </div>;
}

export default Message;